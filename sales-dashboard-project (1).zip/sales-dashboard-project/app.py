import streamlit as st
import pandas as pd
from pathlib import Path

from src.data_prep import load_data, engineer_features, compute_kpis, cohort_matrix, rfm
from src.utils import apply_filters
from src.charts import sales_over_time, bar_sales_by_category, bar_top_products, cohort_heatmap

st.set_page_config(page_title="Sales Analytics Dashboard", page_icon="📊", layout="wide")

st.title("📊 Sales Data Dashboard")
st.caption("Analyse sales trends and patterns using Pandas, Matplotlib & Streamlit")

# ---- Data Loader ----
default_path = Path("data/sales.csv")
uploaded = st.sidebar.file_uploader("Upload your sales CSV (optional)", type=["csv"])
if uploaded is not None:
    df = load_data(uploaded)
else:
    st.sidebar.info("Using bundled sample data: data/sales.csv")
    df = load_data(default_path)

df = engineer_features(df)

# ---- Filters ----
st.sidebar.header("Filters")
date_range = st.sidebar.date_input("Date range", value=[df["order_date"].min().date(), df["order_date"].max().date()])
regions = st.sidebar.multiselect("Region", sorted(df["region"].dropna().unique().tolist()))
segments = st.sidebar.multiselect("Segment", sorted(df["segment"].dropna().unique().tolist()))
categories = st.sidebar.multiselect("Category", sorted(df["category"].dropna().unique().tolist()))
states = st.sidebar.multiselect("State", sorted(df["state"].dropna().unique().tolist()))
cities = st.sidebar.multiselect("City", sorted(df["city"].dropna().unique().tolist()))

fdf = apply_filters(df, date_range=date_range, regions=regions, segments=segments, categories=categories, states=states, cities=cities)

st.write(f"**Rows after filters:** {len(fdf):,}")

# ---- KPI Cards ----
kpis = compute_kpis(fdf)
c1, c2, c3, c4, c5 = st.columns(5)
c1.metric("Total Revenue", f"₹{kpis['total_revenue']:,.0f}")
c2.metric("Total Profit", f"₹{kpis['total_profit']:,.0f}")
c3.metric("Units Sold", f"{kpis['units_sold']:,}")
c4.metric("Avg Order Value", f"₹{kpis['avg_order_value']:,.0f}")
c5.metric("Returning Cust. Rate", f"{kpis['returning_customer_rate']*100:.1f}%")

st.divider()

# ---- Charts Row 1 ----
col1, col2 = st.columns(2)
with col1:
    st.subheader("Revenue over Time")
    freq = st.selectbox("Frequency", ["D","W","M","Q","Y"], index=2, key="freq_select")
    st.pyplot(sales_over_time(fdf, freq=freq))

with col2:
    st.subheader("Revenue by Category")
    st.pyplot(bar_sales_by_category(fdf))

st.divider()

# ---- Charts Row 2 ----
col3, col4 = st.columns(2)
with col3:
    st.subheader("Top Products")
    n = st.slider("How many products?", min_value=5, max_value=25, value=10, step=1, key="top_n")
    st.pyplot(bar_top_products(fdf, n=n))

with col4:
    st.subheader("Cohort Retention")
    matrix = cohort_matrix(fdf)
    st.pyplot(cohort_heatmap(matrix))

st.divider()

# ---- RFM Table ----
st.subheader("RFM Segmentation (Top 50)")
rfm_df = rfm(fdf).head(50)
st.dataframe(rfm_df, use_container_width=True)

st.caption("Tip: Upload your own CSV with at least these columns: order_id, order_date, ship_date, customer_id, segment, region, category, sub_category, product_id, product_name, quantity, unit_price, discount, shipping_cost, revenue, profit.")
