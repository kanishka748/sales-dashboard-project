# 📊 Sales Data Dashboard (Streamlit + Pandas + Matplotlib)

An end-to-end, analyst-grade sales analytics project you can run locally and deploy to Streamlit Cloud. 
Includes synthetic sample data, modular data-prep code, and interactive charts powered by Matplotlib.

## ✨ Features
- Filters: date range, region, segment, category, state, city
- KPIs: Total Revenue, Total Profit, Units Sold, Average Order Value, Returning Customer Rate
- Charts: Revenue over time, Revenue by category, Top products, Cohort retention heatmap
- RFM Segmentation table (1–5 scoring per R/F/M)
- Upload your own CSV or use the included sample dataset

## 🗂️ Project Structure
```
sales-dashboard-project/
├─ app.py
├─ data/
│  └─ sales.csv
├─ src/
│  ├─ data_prep.py
│  ├─ charts.py
│  └─ utils.py
├─ notebooks/
│  └─ 01_exploratory_analysis.ipynb
├─ requirements.txt
├─ .gitignore
└─ LICENSE
```

## ▶️ Quickstart
```bash
# 1) Create a virtual environment (recommended)
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# 2) Install dependencies
pip install -r requirements.txt

# 3) Run Streamlit app
streamlit run app.py
```

## 📤 Use Your Own Data
Your CSV should include at least these columns:
`order_id, order_date, ship_date, customer_id, segment, region, category, sub_category, product_id, product_name, quantity, unit_price, discount, shipping_cost, revenue, profit`

Dates should be parseable by pandas (YYYY-MM-DD recommended). Revenue & profit will be recomputed if missing.

## 🧠 Analyst Notes
- **Cohort analysis** groups customers by first purchase month and shows retention across months.
- **RFM** scores customers on Recency, Frequency, and Monetary value. Combine into a 3-digit code (e.g., 555 = best).
- Use filters to isolate regions or product lines and watch KPIs/charts update.

## ☁️ Deploy on Streamlit Cloud
1. Push this repo to GitHub.
2. On [share.streamlit.io](https://share.streamlit.io), set **Main file path** to `app.py`.
3. Add `requirements.txt` and the `data/` folder to your repo.

## 📝 License
This project is released under the MIT License. See `LICENSE` for details.
