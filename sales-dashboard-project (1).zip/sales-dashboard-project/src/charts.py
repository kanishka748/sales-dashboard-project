import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

# Note: Streamlit will render these matplotlib figures returned by functions.

def sales_over_time(df: pd.DataFrame, freq: str = "M"):
    data = df.set_index("order_date").resample(freq)["revenue"].sum()
    fig, ax = plt.subplots()
    data.plot(ax=ax)
    ax.set_title(f"Revenue over time ({freq})")
    ax.set_xlabel("Date")
    ax.set_ylabel("Revenue")
    ax.grid(True, alpha=0.3)
    return fig

def bar_sales_by_category(df: pd.DataFrame):
    data = df.groupby("category")["revenue"].sum().sort_values(ascending=False)
    fig, ax = plt.subplots()
    data.plot(kind="bar", ax=ax)
    ax.set_title("Revenue by Category")
    ax.set_xlabel("Category")
    ax.set_ylabel("Revenue")
    ax.grid(True, axis="y", alpha=0.3)
    return fig

def bar_top_products(df: pd.DataFrame, n: int = 10):
    data = df.groupby("product_name")["revenue"].sum().sort_values(ascending=False).head(n)
    fig, ax = plt.subplots()
    data.plot(kind="barh", ax=ax)
    ax.set_title(f"Top {n} Products by Revenue")
    ax.set_xlabel("Revenue")
    ax.set_ylabel("Product")
    ax.invert_yaxis()
    ax.grid(True, axis="x", alpha=0.3)
    return fig

def cohort_heatmap(matrix: pd.DataFrame):
    fig, ax = plt.subplots()
    im = ax.imshow(matrix.values, aspect="auto")
    ax.set_title("Cohort Retention (Monthly)")
    ax.set_xlabel("Months since first purchase")
    ax.set_ylabel("Cohort (YYYY-MM)")
    ax.set_xticks(range(matrix.shape[1]))
    ax.set_xticklabels(matrix.columns.astype(int), rotation=0)
    ax.set_yticks(range(matrix.shape[0]))
    ax.set_yticklabels([idx.strftime("%Y-%m") for idx in matrix.index])
    # Add values on heatmap
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            val = matrix.values[i, j]
            ax.text(j, i, f"{val:.0%}", ha="center", va="center", fontsize=7)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    return fig
