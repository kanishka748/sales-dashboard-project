import pandas as pd
import numpy as np

# --------------------
# Data loading & cleaning
# --------------------
def load_data(path: str) -> pd.DataFrame:
    df = pd.read_csv(path, parse_dates=["order_date", "ship_date"])
    # Basic sanity fixes
    df = df.drop_duplicates(subset=["order_id", "product_id", "order_date"]).reset_index(drop=True)
    # Ensure numeric columns are proper dtype
    num_cols = ["quantity","unit_price","discount","shipping_cost","revenue","profit"]
    for c in num_cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["discount"] = df["discount"].clip(lower=0, upper=0.9)
    df["revenue"] = df["revenue"].fillna(df["quantity"] * df["unit_price"] * (1 - df["discount"]))
    df["profit"] = df["profit"].fillna(df["revenue"] * 0.2 - df["shipping_cost"])
    return df

# --------------------
# Feature engineering
# --------------------
def engineer_features(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    d["order_month"] = d["order_date"].dt.to_period("M").dt.to_timestamp()
    d["order_week"] = d["order_date"].dt.to_period("W").dt.start_time
    d["aov"] = d["revenue"] / d["quantity"].replace(0, np.nan)
    return d

# --------------------
# KPI calculations
# --------------------
def compute_kpis(df: pd.DataFrame) -> dict:
    total_rev = float(df["revenue"].sum())
    total_profit = float(df["profit"].sum())
    units = int(df["quantity"].sum())
    aov = float((df["revenue"].sum() / df["order_id"].nunique()) if df["order_id"].nunique() else 0.0)

    # Returning customer rate: customers with >1 orders in period / all customers with >=1
    orders_by_cust = df.groupby(["customer_id","order_id"]).size().reset_index().groupby("customer_id")["order_id"].nunique()
    returning_cust_rate = float((orders_by_cust.gt(1).sum() / orders_by_cust.shape[0]) if orders_by_cust.shape[0] else 0.0)

    return {
        "total_revenue": round(total_rev, 2),
        "total_profit": round(total_profit, 2),
        "units_sold": units,
        "avg_order_value": round(aov, 2),
        "returning_customer_rate": round(returning_cust_rate, 3)
    }

# --------------------
# Cohort analysis (monthly)
# --------------------
def cohort_matrix(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    d["order_month"] = d["order_date"].dt.to_period("M").dt.to_timestamp()
    # First purchase month per customer
    first_purchase = d.groupby("customer_id")["order_month"].min().rename("cohort")
    d = d.join(first_purchase, on="customer_id")
    d["period_number"] = ((d["order_month"].dt.year - d["cohort"].dt.year) * 12 +
                          (d["order_month"].dt.month - d["cohort"].dt.month))
    # Cohort size
    cohort_size = d.groupby("cohort")["customer_id"].nunique()
    # Active customers per period relative to cohort
    active = d.groupby(["cohort","period_number"])["customer_id"].nunique().unstack(fill_value=0)
    retention = active.divide(cohort_size, axis=0).fillna(0)
    # Limit to first 12 months for readability
    retention = retention.loc[:, retention.columns.sort_values()]
    retention = retention.iloc[:, :12] if retention.shape[1] > 12 else retention
    return retention

# --------------------
# Simple RFM scoring
# --------------------
def rfm(df: pd.DataFrame, as_of=None) -> pd.DataFrame:
    d = df.copy()
    if as_of is None:
        as_of = d["order_date"].max()
    metrics = d.groupby("customer_id").agg(
        recency=("order_date", lambda x: (as_of - x.max()).days),
        frequency=("order_id", "nunique"),
        monetary=("revenue", "sum")
    ).reset_index()

    # Score each into 1-5 quintiles
    metrics["R"] = pd.qcut(-metrics["recency"], 5, labels=False, duplicates="drop") + 1  # recent is good
    metrics["F"] = pd.qcut(metrics["frequency"].rank(method="first"), 5, labels=False) + 1
    metrics["M"] = pd.qcut(metrics["monetary"].rank(method="first"), 5, labels=False) + 1
    metrics["RFM_Score"] = metrics["R"].astype(int)*100 + metrics["F"].astype(int)*10 + metrics["M"].astype(int)
    return metrics.sort_values("RFM_Score", ascending=False)
