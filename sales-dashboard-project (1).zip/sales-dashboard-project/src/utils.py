import pandas as pd

def apply_filters(df: pd.DataFrame, date_range=None, regions=None, segments=None, categories=None, states=None, cities=None):
    d = df.copy()
    if date_range and date_range[0] and date_range[1]:
        d = d[(d["order_date"] >= pd.to_datetime(date_range[0])) & (d["order_date"] <= pd.to_datetime(date_range[1]))]
    if regions and len(regions) > 0:
        d = d[d["region"].isin(regions)]
    if segments and len(segments) > 0:
        d = d[d["segment"].isin(segments)]
    if categories and len(categories) > 0:
        d = d[d["category"].isin(categories)]
    if states and len(states) > 0:
        d = d[d["state"].isin(states)]
    if cities and len(cities) > 0:
        d = d[d["city"].isin(cities)]
    return d
